How to run the code :

- All the code file should be in same folder
- Need to have a folder named as 'frames' in the same directory
- Need only to run the main.py
- At a stage it will ask for a pixel input for the worm

Video link is here (only ttu domain has authorization to watch the video) -

https://texastechuniversity-my.sharepoint.com/:v:/g/personal/m_zaman_ttu_edu/EWZyGRxzsBJLqW_2KtUqrK4BftnlyDU6oVVffbURVpRw8Q?e=UswRZP&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D


powerpoint presentation:

Last slide is added after presentation to show the skeleton.